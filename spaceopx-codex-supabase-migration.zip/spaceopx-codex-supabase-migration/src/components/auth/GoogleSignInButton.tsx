import { useState } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { authService } from "@/services/auth";

export function GoogleSignInButton({ destination }: { destination: string }) {
  const [busy, setBusy] = useState(false);
  async function connect() {
    setBusy(true);
    try { await authService.signInWithGoogle(destination); }
    catch (error) { toast.error(error instanceof Error && error.message === "google_registration_not_configured" ? "O cadastro com Google ainda está sendo configurado. Use e-mail e senha por enquanto." : "Não foi possível conectar ao Google. Tente novamente ou use e-mail e senha."); }
    finally { setBusy(false); }
  }
  return <div className="mb-5 space-y-4">
    <Button type="button" variant="outline" className="w-full gap-3" disabled={busy} onClick={connect}>
      <svg aria-hidden="true" width="18" height="18" viewBox="0 0 24 24"><path fill="#4285F4" d="M21.6 12.23c0-.71-.06-1.39-.18-2.05H12v3.88h5.38a4.6 4.6 0 0 1-2 3.02v2.51h3.24c1.89-1.74 2.98-4.3 2.98-7.36Z"/><path fill="#34A853" d="M12 22c2.7 0 4.96-.9 6.62-2.41l-3.24-2.51c-.9.6-2.04.96-3.38.96-2.6 0-4.8-1.76-5.59-4.12H3.06v2.59A10 10 0 0 0 12 22Z"/><path fill="#FBBC05" d="M6.41 13.92A6 6 0 0 1 6.1 12c0-.67.11-1.32.31-1.92V7.49H3.06A10 10 0 0 0 2 12c0 1.61.38 3.14 1.06 4.51l3.35-2.59Z"/><path fill="#EA4335" d="M12 5.96c1.47 0 2.79.5 3.82 1.5l2.87-2.87A9.6 9.6 0 0 0 12 2a10 10 0 0 0-8.94 5.49l3.35 2.59C7.2 7.72 9.4 5.96 12 5.96Z"/></svg>
      {busy ? "Conectando…" : "Continuar com Google"}
    </Button>
    <div className="text-muted-foreground text-center text-xs">ou continue com e-mail</div>
  </div>;
}
